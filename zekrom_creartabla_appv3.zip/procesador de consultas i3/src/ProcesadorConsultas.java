import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ProcesadorConsultas {

    public static boolean validarRol(String rol) {
        return rol.equalsIgnoreCase("DBA"); //Devuelve true si el rol es DBA
    }

    public static String leerSentencia(){
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();  //Devuelve en un String lo que escriba el usuario
    }

    public static List<String> dividirEnTokens(String sentencia) {
        String sinPuntoYComa = sentencia.substring(0, sentencia.length() - 1); //El -1 es porque el último carácter de la sentencia es ";"
        String[] partes = sinPuntoYComa.trim().split("\\s+|(?=[(),])|(?<=[(),])");
    
        // Filtrar strings vacíos
        List<String> tokens = new ArrayList<>();
        for (String parte : partes) {
            if (!parte.trim().isEmpty()) {
                tokens.add(parte);
            }
        }

        return tokens; //Devuelve los tokens
    }
    
    // - - - - - VALIDACIONES DE SINTAXIS - - - - -
    
    //validarSintaxis1 valida la sintaxis de creación de usuario
    //validarSintaxis2 valida la sintaxis de eliminación de usuario
    
    public static boolean validarSintaxisMakeUser(List<String> tokens){
        if (tokens.size() == 5) { //Pregunta si la sentencia tiene 5 tokens (MAKE USER <usuario> PASSWORD <contraseña>)
            
            return tokens.get(0).equalsIgnoreCase("MAKE") && //Pregunta si el primer token (palabra) es MAKE
                   tokens.get(1).equalsIgnoreCase("USER") && //Pregunta si el segundo token es USER
                   !tokens.get(2).isEmpty() &&               //Se asegura que el token no esté vacío
                   tokens.get(3).equalsIgnoreCase("PASSWORD") && //Pregunta que el cuarto token sea PASSWORD
                   !tokens.get(4).isEmpty() &&  //Se asegura que el quinto campo no esté vacío
                   tokens.get(4).matches("^'.*'$");  //Se asegura la contraseña este entre ' '
                                                                
                        //Puede ser que si se intenta escribir un usuarios 
                        //y contraseña con espacios el sistema no lo valide correctamente
        } else {                                             
            return false;
        }
    }
    
    public static boolean validarSintaxisDropUser(List<String> tokens){ 
        if(tokens.size() == 3){ //Pregunta si la sentencia tiene 3 tokens (DROP USER <usuario>)
            
            return tokens.get(0).equalsIgnoreCase("DROP") && //Pregunta si el primer token es DROP
                   tokens.get(1).equalsIgnoreCase("USER") && //Pregunta si el segundo token es USER
                   !tokens.get(2).isEmpty(); //Se asegura que el token no este vacio
            
        }else{
            return false;
        }
    }
    public static boolean validarSintaxisAlterUser(List<String> tokens){
        if(tokens.size() == 6){ //Pregunta si la sentencia tiene 6 tokens (ALTER USER <usuario> NEW PASSWORD <contraseña>)
            
            return tokens.get(0).equalsIgnoreCase("ALTER") && //Pregunta si el primer token (palabra) es MAKE
                   tokens.get(1).equalsIgnoreCase("USER") && //Pregunta si el segundo token es USER
                   !tokens.get(2).isEmpty() &&               //Se asegura que el token no esté vacío
                   tokens.get(3).equalsIgnoreCase("NEW")&& //Se asegura que el cuarto token sea NEW
                   tokens.get(4).equalsIgnoreCase("PASSWORD") && //Pregunta que el quinto token sea PASSWORD
                   !tokens.get(5).isEmpty() &&  //Se asegura que el sexto campo no esté vacío
                   tokens.get(5).matches("^'.*'$");  //Se asegura la contraseña este entre ' '}              
            
        }else{
            return false;
        }
    }
    
    public static boolean validarSintaxisMakeTable(List<String> tokens){
        if(tokens.size() >= 7){
            return tokens.get(0).equalsIgnoreCase("MAKE") &&
                   tokens.get(1).equalsIgnoreCase("TABLE") &&
                   tokens.get(2).matches("[a-zA-Z][a-zA-Z0-9_]*") &&
                   tokens.get(3).equals("(") && 
                   tokens.get(tokens.size() - 1).equals(")");
        } else{
            return false;
        }
    }
    
    public static boolean validarColumnasMakeTable(List<String> tokens){
        List<List<String>> columnas = obtenerListColumnas(tokens);
        
        if(!columnas.isEmpty()){
            return false;
        }

        // Validar cada columna
        for (List<String> columna : columnas) {
            if (columna.size() < 2) {
                return false; // Cada columna debe tener al menos tipo y nombre
            }

            String tipo = columna.get(0).toUpperCase();
            String nombre = columna.get(1);

            // Validar tipo de dato
            if (!esTipoDatoValido(tipo)) {
                return false;
            }

            // Validar nombre de columna
            if (!nombre.matches("[a-zA-Z][a-zA-Z0-9_]*")) {
                return false;
            }
        }

        return true;
       
    }
    
    public static boolean PuntoComa(String sentencia){
        return sentencia.endsWith(";");
    }

    // Cambié esta función para separar correctamente el usuario
    public static boolean usuarioExistente(List<String> tokens){
        if(tokens.size() < 3){ // Si no hay al menos 3 tokens, no existe usuario
            return false;
        }
        
        String usuario = tokens.get(2);
        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String linea;
            while((linea = br.readLine()) != null){
                String[] partes = linea.split(","); //Divide la linea leída en partes
                if(partes[0].equals(usuario)){ //Pregunta si el usuario ingresado por el usuario ya existe en usuarios.txt
                    return true; // usuario ya existe
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false; // usuario no existe
    }

    public static boolean tablaExistente(List<String> tokens) {
        if (tokens.size() < 3) {
            return false;
        }

        String nombreTabla = tokens.get(2);
        try (BufferedReader br = new BufferedReader(new FileReader("datostabla.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().equalsIgnoreCase(nombreTabla)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void guardarUsuario(String usuario, String contraseña){
        try (
            FileWriter fw = new FileWriter("usuarios.txt", true);
            BufferedWriter bw = new BufferedWriter(fw)
        ) {
            bw.write(usuario + "," + contraseña);         
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void guardarTabla(List<String> tokens) {
        String nombreTabla = tokens.get(2);
        
        File carpetaTablas = new File("tablas");
        if (!carpetaTablas.exists()) {
            carpetaTablas.mkdir();
        }
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("datostabla.txt", true))) {
            bw.write(nombreTabla);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        crearArchivoTabla(tokens);
    }
    
    private static void crearArchivoTabla(List<String> tokens) {
        String nombreTabla = tokens.get(2);
        String nombreArchivo = "tablas/" + nombreTabla + ".txt";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo))) {
            bw.write("ESTRUCTURA:");
            bw.newLine();
            
            
            List<List<String>> columnas = obtenerListColumnas(tokens);

            // Formato: nombre:tipo
            for (List<String> columna : columnas) {
                String nombreColumna = columna.get(1);
                String tipoColumna = columna.get(0).toUpperCase();
                bw.write(nombreColumna + ":" + tipoColumna);
                bw.newLine();
            }
            
            bw.newLine();
            bw.write("DATOS:");
            bw.newLine();

        } catch (IOException e) {
            System.out.println("Error al crear archivo de tabla: " + e.getMessage());
        }
    }

    
    public static void modificarUsuario(String usuario, String nuevaContrasena) {
        List<String> lineas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if(partes[0].equals(usuario)){
                    lineas.add(usuario + "," + nuevaContrasena); // Reemplazar la contraseña
                } else {
                    lineas.add(linea);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("usuarios.txt"))) {
            for (String l : lineas) {
                bw.write(l);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void eliminarUsuario(String usuario) {
        File archivo = new File("usuarios.txt");
        File archivoTemp = new File("usuarios_temp.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(archivo));
             BufferedWriter bw = new BufferedWriter(new FileWriter(archivoTemp))) {

            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");

                // Pregunta: si no es el usuario a eliminar, se copia
                if (!partes[0].equals(usuario)) {
                    bw.write(linea);
                    bw.newLine();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Reemplazo el archivo original con el temporal
        if (archivo.delete()) {
            archivoTemp.renameTo(archivo);
        }
    } 

    private static boolean esTipoDatoValido(String tipo){
        List<String> tiposValidos = Arrays.asList("INT", "CHAR", "VARCHAR", "FLOAT", "DOUBLE", "BOOL");
        return tiposValidos.contains(tipo.toUpperCase());
    }
    
    private static List<List<String>> obtenerListColumnas(List<String> tokens){
        List<String> tokensColumnas = tokens.subList(4, tokens.size()-1);
        List<List<String>> columnas = new ArrayList<>();
        List<String> columnaActual = new ArrayList<>();

        if(!tokensColumnas.isEmpty()){

            for (String token : tokensColumnas) {
                if (token.equals(",")) {
                    if (!columnaActual.isEmpty()) {
                        columnas.add(new ArrayList<>(columnaActual));
                        columnaActual.clear();
                    }
                } else {
                    columnaActual.add(token);
                }
            }
            if (!columnaActual.isEmpty()) {
                columnas.add(new ArrayList<>(columnaActual));
            }
            
        }
        
        return columnas;
    }
}

package servidor;

import java.util.ArrayList;
import java.util.List;

public class Main {
    
    public static void main(String[] args) {
        /*
        Servidor servidor = new Servidor();
        servidor.iniciar();
        */
        
        ProcesadorConsultas pc = new ProcesadorConsultas();
        
        // - - - - - Sentencia dividida en tokens hardcodeada - - - - - 
        
        List<String> tokens = new ArrayList<>();
        tokens.add("MAKE");
        tokens.add("DATABSE");
        tokens.add("MiBase");
        
        // - - - - - Validación de Sintaxis de MAKE DATABASE - - - - - 
        
        boolean check = pc.validarSintaxis(tokens);
        
        if(check){
            System.out.println("Sentencia valida (MAKE DATABASE)");
        }
        else{
            System.out.println("Sentencia invalida (MAKE DATABASE)");
        }
        
        
        
        
        // - - - - - Switch para MAKE DATABASE - - - - - 
        
        int resultado = pc.crearBDD("Hola");
        
        switch (resultado){
            case 1:
                System.out.println("ERROR - Nombre de la base de datos ya existente");
                break;
            
            case 2:
                System.out.println("Base de datos creada!!");
                break;
            case 3:
                System.out.println("ERROR - No se pudo crear la base de datos");
        }
        
        // - - - - - Sentencia dividida en tokens hardcodeada - - - - - 

        tokens = new ArrayList<>();
        tokens.add("DROP");
        tokens.add("DAABASE");
        tokens.add("MiBase");
        
        
        // - - - - - Validación de Sintaxis de DROP DATABASE - - - - - 
        
        check = pc.validarSintaxis(tokens);
        
        if(check){
            System.out.println("Sentencia valida (DROP DATABASE)");
        }
        else{
            System.out.println("Sentencia invalida (DROP DATABASE)");
        }
        
        // - - - - - Switch para DROP DATABASE - - - - - 
        
        resultado = pc.eliminarBDD("Hola");
        
        switch (resultado) {
        case 1:
            System.out.println("ERROR - La carpeta no existe");
            break;
        case 2:
            System.out.println("Carpeta eliminada correctamente");
            break;
        case 3:
            System.out.println("ERROR - No se pudo eliminar la carpeta");
            break;
        }
        
    }
    
}


package servidor;

import java.util.*;
import java.io.*;

public class GestorAlmacenamiento {
    private String directorio;
    private Map<String, String> usuarios; 
    
    public GestorAlmacenamiento() {
        this.directorio = "SGBD/";
        this.usuarios = new HashMap<>();
        inicializarDirectorio();
        
        cargarUsuarios();
    }
    
    private void inicializarDirectorio() {
        File f_directorio = new File(directorio);
        if (!f_directorio.exists()) {
            if (f_directorio.mkdirs()) {
                System.out.println("Directorio de datos creado.");
            }
        }
    }
    
    public boolean buscarUsuario(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        return usuarios.containsKey(username) && usuarios.get(username).equals(password);
    }
    
    public boolean buscarUsuario(String username) {
        if (username == null) {
            return false;
        }
        return usuarios.containsKey(username);
    }
    
    private void cargarUsuarios() {
        File archivoUsuarios = new File(directorio + "usuarios.txt");
        
        if (!archivoUsuarios.exists()) {
            crearArchivoUsuarios();
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoUsuarios))) {
            String linea;
            
            while ((linea = reader.readLine()) != null) {
                linea = linea.trim();
                if (!linea.isEmpty()) {
                    String[] partes = linea.split(",", 2);
                    if (partes.length == 2) {
                        String user = partes[0].trim();
                        String pass = partes[1].trim();
                        usuarios.put(user, pass);
                    }
                }
            }
            
            System.out.println("Usuarios cargados.");
        } catch (IOException e) {
            System.err.println("Error cargando usuarios: " + e.getMessage());
        }
    }
    
    private void crearArchivoUsuarios() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(directorio + "usuarios.txt"))) {
            writer.println("root,12341234");
            System.out.println("Archivo de usuarios creado: usuarios.txt");
            
        } catch (IOException e) {
            System.err.println("Error creando archivo de usuarios: " + e.getMessage());
        }
    }
    
    public int getPuerto(){
        try (BufferedReader br = new BufferedReader(new FileReader("IPConfig.txt"))) {
            br.readLine();
            String puerto = br.readLine();
            return Integer.parseInt(puerto);
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error leyendo el puerto: " + e.getMessage());
            return -1;
        }
    }
    
    public static boolean usuarioExistente(String usuario){
        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String linea;
            while((linea = br.readLine()) != null){
                String[] partes = linea.split(","); //Divide la linea leída en partes
                if(partes[0].equals(usuario)){ //Pregunta si el usuario ingresado por el usuario ya existe en usuarios.txt
                    return true; // usuario ya existe
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false; // usuario no existe
    }
}
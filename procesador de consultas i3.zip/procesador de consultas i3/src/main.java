

import java.util.*;

public class main {    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); 
        
        System.out.print("Ingresa la consulta SQL: ");
        String consulta = scanner.nextLine(); 
        //consulta = "TABLE Estudiantes (INT DNI, CHAR Apellidos);";
        
        System.out.println("Validando consulta: " + consulta);
        boolean resultado = validarConsulta(consulta);
        System.out.println("Resultado: " + (resultado ? "VALIDA" : "INVALIDA"));
        
        GestorAlmacenamiento.mostrarTablasExistentes();
    }
    
    public static boolean validarConsulta(String consulta) {
        try {
            List<String> tokens = tokenizar(consulta);
            
            
            if (!validarSintaxis(tokens)) {
                return false;
            }
            
            if (!validarSemantica(tokens)){
                return false;
            }
            
            GestorAlmacenamiento.guardarTabla(tokens.get(1));
            return true;
            
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
    
    private static List<String> tokenizar(String consulta) {
        List<String> tokens = new ArrayList<>();
        
        String[] partes = consulta.split("(?=[(),;])|(?<=[(),;])|\\s+");
        
        for (String parte : partes) {
            String aux = parte.trim();
            if (!aux.isEmpty()) {
                tokens.add(aux);
            }
        }
        
        System.out.println("Analisis Lexico: " + tokens.size() + " tokens = " + tokens);
        
        return tokens;
    }
    
    private static boolean validarSintaxis(List<String> tokens) {        
        if (tokens.size() < 6) {
            System.out.println("Error sintactico: Consulta invalida por falta de tokens");
            return false;
        }
        
    /*    if (!tokens.get(0).toUpperCase().equals("TABLE")) {
            System.out.println("Error sintactico: No es un TABLE");
            return false;
        } */
        
        // -------------------------Sintaxis TABLE-------------------------
        
        
        if (tokens.get(0).equalsIgnoreCase("TABLE")) { //Pregunta si el primer token es "TABLE"
            
            
            if (!tokens.get(1).matches("[a-zA-Z][a-zA-Z0-9_]*")) {
                System.out.println("Error sintactico Nombre de tabla invalido: " + tokens.get(1));
                return false;
            }

            if (!tokens.get(2).equals("(")) {
                System.out.println("Error sintactico: Se esperaba un '(' despues del nombre de la tabla");
                return false;
            }

            if (!tokens.get(tokens.size() - 2).equals(")")) {
                System.out.println("Error sintactico: Se esperaba un ')' antes del ';'");
                return false;
            }

            if (!tokens.get(tokens.size() - 1).equals(";")) {
                System.out.println("Error sintactico: La consulta debe terminar con ';'");
                return false;
            }

            // Extrae los tokens de las columnas
            List<String> tokensColumna = new ArrayList<>();
            for (int i = 3; i < tokens.size() - 2; i++) {
                tokensColumna.add(tokens.get(i));
            }

            // Analisis sintactico de las columnas
            return validarColumnas(tokens);

        }
        
        else{
            return false;
        }
    
    } //Cierra el método
    
    private static boolean validarColumnas(List<String> tokens) {
        List<List<String>> columnas = extraerColumnas(tokens);
        if(columnas.isEmpty()){
            System.out.println("Error sintactico: No hay columnas.");
            return false;
        }
        
        System.out.println("Columnas: " + columnas);
        
        // Validacion por columna
        for (List<String> columna : columnas) {
            if (columna.size() != 2) {
                System.out.println("Error sintactico: Error en los tokens de columnas. Se esperaban 2 tokens pero hay: " + columna);
                return false;
            }
            
            String tipo = columna.get(0);
            String nombre = columna.get(1);
            
            // Validación sintactica del nombre
            if (!nombre.matches("[a-zA-Z][a-zA-Z0-9_]*")) {
                System.out.println("Error sintactico: Formato de nombre de columna inválido: " + nombre);
                return false;
            }
            
            System.out.println("Columna sintacticamente valida: " + tipo + " " + nombre);
        }
        
        return true;
    }
    
    private static boolean validarSemantica(List<String> tokens) {
        String nombreTabla = tokens.get(1);
        
        boolean tablaExiste = (Boolean) GestorAlmacenamiento.consultarDiccionario(
            GestorAlmacenamiento.TipoConsulta.EXISTE_TABLA, 
            nombreTabla
        );
        
        if (tablaExiste) {
            System.out.println("Error semantico: La tabla '" + nombreTabla + "' ya existe");
            return false;
        }
        
        List<List<String>> columnas = extraerColumnas(tokens);
        
        List<String> tiposValidos = (List<String>) GestorAlmacenamiento.consultarDiccionario(
            GestorAlmacenamiento.TipoConsulta.OBTENER_TIPOS_DATO
        );
        
        for (List<String> columna : columnas) {
            String tipo = columna.get(0).toUpperCase();
            if (!tiposValidos.contains(tipo)) {
                System.out.println("Error semantico: Tipo de dato '" + tipo + "' no válido");
                return false;
            }
        }
        
        return true;
    }
    
    private static List<List<String>> extraerColumnas(List<String> tokens) {
        List<String> tokensColumna = new ArrayList<>();
        
        for (int i = 3; i < tokens.size() - 2; i++) {
            tokensColumna.add(tokens.get(i));
        }
        
        List<List<String>> columnas = new ArrayList<>();
        List<String> columnaActual = new ArrayList<>();
        
        for (String token : tokensColumna) {
            if (token.equals(",")) {
                if (!columnaActual.isEmpty()) {
                    columnas.add(new ArrayList<>(columnaActual));
                    columnaActual.clear();
                }
            } else {
                columnaActual.add(token);
            }
        }
        if (!columnaActual.isEmpty()) {
            columnas.add(new ArrayList<>(columnaActual));
        }
        
        return columnas;
    }
}


import java.io.*;
import java.util.*;

public class GestorAlmacenamiento {
    private static final String ARCHIVO_TABLAS = "tablas.txt";
    
    public enum TipoConsulta {
        EXISTE_TABLA,
        OBTENER_TIPOS_DATO
    }
    
    public static Object consultarDiccionario(TipoConsulta tipo, Object... parametros) {
        switch (tipo) {
            case EXISTE_TABLA:
                String nombre = (String) parametros[0];
                return existeTabla(nombre);
                
            case OBTENER_TIPOS_DATO:
                return obtenerTiposDeDato();
                
            default:
                throw new IllegalArgumentException("Consulta invalida");
        }
    }
    
    private static boolean existeTabla(String nombre) {
        try {
            File archivo = new File(ARCHIVO_TABLAS);
            if (!archivo.exists()) {
                return false;
            }
            
            try (Scanner scanner = new Scanner(archivo)) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine().trim();
                    if (linea.equalsIgnoreCase(nombre)) {
                        scanner.close();
                        return true;
                    }
                }
            }
            return false;
            
        } catch (FileNotFoundException e) {
            return false;
        }
    }
    
    public static boolean guardarTabla(String nombre) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_TABLAS, true))) {
            writer.println(nombre);
            return true;
        } catch (IOException e) {
            System.out.println("Error al guardar tabla: " + e.getMessage());
            return false;
        }
    }
    
    private static List<String> obtenerTiposDeDato() {
        List<String> tipos = new ArrayList<>();
        tipos.add("INT");
        tipos.add("CHAR");
        tipos.add("VARCHAR");
        tipos.add("FLOAT");
        tipos.add("DOUBLE");
        tipos.add("BOOL");
        return tipos;
    }
    
    public static void mostrarTablasExistentes() {
        try {
            File archivo = new File(ARCHIVO_TABLAS);
            if (!archivo.exists()) {
                System.out.println("No hay tablas existentes");
                return;
            }
            
            System.out.println("\n---------- TABLAS EN EL SISTEMA ----------");
            try (Scanner scanner = new Scanner(archivo)) {
                int contador = 1;
                while (scanner.hasNextLine()) {
                    System.out.println(contador + ". " + scanner.nextLine());
                    contador++;
                }
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer archivo de tablas");
        }
    }
}
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String rol = "DBA"; // esto puede venir de un login en el futuro

        if (!ProcesadorConsultas.validarRol(rol)) {
            System.out.println("CREACIÓN DENEGADA - No tienes permisos de DBA");
            return;
        }
        
        ProcesadorConsultas.crearArchivoBDD();
        
        while(true){
            
            System.out.println("- - - Ingresar Consulta - - -");
            String sentencia = ProcesadorConsultas.leerSentencia();
            List<String> tokens = ProcesadorConsultas.dividirEnTokens(sentencia); //Divide en partes (tokens) la sentencia
            
            if(tokens.size() <= 2){
                System.out.println("ERROR - Sintaxis inválida");
            }
            
            else if (tokens.get(0).equalsIgnoreCase("MAKE")) { //Pregunta si la primera palabra de la sentencia es MAKE
                if (tokens.size() > 1 && tokens.get(1).equalsIgnoreCase("USER")){
                    boolean check1 = ProcesadorConsultas.PuntoComa(sentencia);
                    boolean check2 = ProcesadorConsultas.validarSintaxisMakeUser(tokens);
                    boolean check3 = !ProcesadorConsultas.usuarioExistente(tokens);

                    if(check1 && check2 && check3){ //Si todas las validaciones están bien

                       String usuario = tokens.get(2); //Toma el usuario de la sentencia
                       String contraseña = tokens.get(4); //Tome la contraseña de la sentencia

                       ProcesadorConsultas.guardarUsuario(usuario, contraseña); //Escribe la sentencia y la contraseña en un archivo

                       System.out.println("SENTENCIA VALIDA");
                       System.out.println("Usuario creado correctamente");


                    }else { 
                        if(!check1){
                            System.out.println("ERROR - La sentencia no finaliza con ';'");
                        }
                        if(!check2){
                            System.out.println("ERROR - Sintaxis inválida");
                        }
                        if(!check3){
                            System.out.println("ERROR - El usuario ingresado ya existe");
                        }
                    }
                }
                
                else if (tokens.size() > 1 && tokens.get(1).equalsIgnoreCase("TABLE")) {
                    boolean check1 = ProcesadorConsultas.PuntoComa(sentencia);
                    boolean check2 = ProcesadorConsultas.validarSintaxisMakeTable(tokens);
                    boolean check3 = ProcesadorConsultas.validarColumnasMakeTable(tokens);
                    boolean check4 = !ProcesadorConsultas.tablaExistente(tokens);

                    if(check1 && check2 && check3 && check4){
                        ProcesadorConsultas.guardarTabla(tokens);
                        System.out.println("SENTENCIA VALIDA");
                        System.out.println("Tabla creada correctamente");
                    } else { 
                        if(!check1){
                            System.out.println("ERROR - La sentencia no finaliza con ';'");
                        }
                        if(!check2){
                            System.out.println("ERROR - Sintaxis inválida");
                        }
                        if(!check3){
                            System.out.println("ERROR - Columna inválida");
                        }
                        if(!check4){
                            System.out.println("ERROR - La tabla ya existe");
                        }
                    }
                }
                else {
                    System.out.println("ERROR - Sintaxis inválida después de MAKE");
                }
            }
             
             //Acá en medio van los demás else if que preguntan si la sentencia
             //empieza con DROP, MODIFY, ETC.
             
            else if(tokens.get(0).equalsIgnoreCase("DROP")){
                 
                boolean check1 = ProcesadorConsultas.PuntoComa(sentencia);
                boolean check2 = ProcesadorConsultas.validarSintaxisDropUser(tokens);
                boolean check3 = ProcesadorConsultas.usuarioExistente(tokens);
               
                if(check1 && check2 && check3){
                   
                   String usuario = tokens.get(2);
                   ProcesadorConsultas.eliminarUsuario(usuario);
                   
                   System.out.println("Usuario Eliminado");
                }else{
                   if(!check1){
                       System.out.println("ERROR - La sentencia no finaliza con ';'");
                   }
                   if(!check2){
                       System.out.println("ERROR - Sintaxis inválida");
                   }
                   if(!check3){
                       System.out.println("ERROR - El usuario ingresado no existe");
                   }
                }
               
            }else if(tokens.get(0).equalsIgnoreCase("ALTER")){
                boolean check1 = ProcesadorConsultas.PuntoComa(sentencia);
                boolean check2 = ProcesadorConsultas.validarSintaxisAlterUser(tokens);
                boolean check3 = ProcesadorConsultas.usuarioExistente(tokens);
                
                if(check1 && check2 && check3){ //Si todas las validaciones están bien

                   String usuario = tokens.get(2); //Toma el usuario de la sentencia
                   String contraseña = tokens.get(4); //Tome la contraseña de la sentencia

                   ProcesadorConsultas.modificarUsuario(usuario, contraseña); //Escribe la sentencia y la contraseña en un archivo
                   System.out.println("SENTENCIA VALIDA");
                   System.out.println("Usuario modificado correctamente");
                   
                }else { 
                    if(!check1){
                        System.out.println("ERROR - La sentencia no finaliza con ';'");
                    }
                    if(!check2){
                        System.out.println("ERROR - Sintaxis inválida");
                    }
                    if(!check3){
                        System.out.println("ERROR - El usuario ingresado no existe");
                    }
                }
            }
            
            else if(tokens.get(0).equalsIgnoreCase("CREATE")){
                boolean check1 = ProcesadorConsultas.PuntoComa(sentencia);
                boolean check2 = ProcesadorConsultas.validarSintaxisCreateDATABASE(tokens);
                boolean check3 = !ProcesadorConsultas.BDDExistente(tokens); 
                
                if(check1 && check2 && check3){ //Si todas las validaciones están bien

                       String nombre = tokens.get(2); //Toma el usuario de la sentencia
                       
                       ProcesadorConsultas.guardarBDD(nombre);
                       

                       System.out.println("SENTENCIA VALIDA");
                       System.out.println("Base de datos creada correctamente");


                    }else { 
                        if(!check1){
                            System.out.println("ERROR - La sentencia no finaliza con ';'");
                        }
                        if(!check2){
                            System.out.println("ERROR - Sintaxis inválida");
                        }
                        if(!check3){
                            System.out.println("ERROR - El nombre ingresado ya existe");
                        }
                    }
                
            }
            
            else{
                 System.out.println("ERROR - Sintaxis inválida");
                 System.out.println("");
            }                        
        }
    }
}
